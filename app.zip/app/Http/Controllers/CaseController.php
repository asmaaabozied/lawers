<?php

namespace App\Http\Controllers;

use App\Model\LawyerCase;
use Illuminate\Http\Request;

class CaseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('cases.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('cases.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'code' => 'required',
            'type_id'=>'required',
//            'discount'=>'required',

            'number' => 'required|unique:cases,number',
            'client_id' => 'required|exists:clients,id',
        ], [], [
            'discount'=>'الخصم',

            'code' => 'الكؤد',
            'number' => 'رقم القضية',
            'client_id' => 'العميل',
            'type_id'=>'النوع'
        ]);
        LawyerCase::create($request->all());
        $this->actionSuccess();
        return redirect()->route('case.index');

    }

    /**
     * Display the specified resource.
     *
     * @param LawyerCase $lawyerCase
     * @return \Illuminate\Http\Response
     */
    public function show(LawyerCase $lawyerCase)
    {
        return view('cases.show', compact('lawyerCase'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param LawyerCase $lawyerCase
     * @return \Illuminate\Http\Response
     */
    public function edit(LawyerCase $lawyerCase)
    {
        return view('cases.edit', compact('lawyerCase'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param LawyerCase $lawyerCase
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, LawyerCase $lawyerCase)
    {

        $request->validate([
            'code' => 'required',
            'type_id'=>'required',
//            'discount'=>'required',

            'number' => 'required|unique:cases,number,' . $lawyerCase['id'],
            'client_id' => 'required|exists:clients,id',
        ], [], [
            'discount'=>'الخصم',
            'type' => 'النوع',
            'number' => 'رقم القضية',
            'client_id' => 'العميل',
            'type_id'=>'النوع'

        ]);
        $lawyerCase->update($request->all());
        $this->actionSuccess();

        return redirect()->route('case.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param LawyerCase $lawyerCase
     * @return \Illuminate\Http\Response
     * @throws \Exception
     */
    public function destroy(LawyerCase $lawyerCase)
    {
        $lawyerCase->delete();
        $this->actionSuccess();
        return back();
    }
}
