<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Lawercase extends Model
{
    protected $guarded = [];
    protected $table = 'lawercases';
}
