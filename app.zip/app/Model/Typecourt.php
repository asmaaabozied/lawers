<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Typecourt extends Model
{
    protected $guarded = [];
    protected $table = 'typecourts';


    public function typecourt()
    {
        return $this->belongsTo(Court::class, 'court_id', 'id');
    }
}
