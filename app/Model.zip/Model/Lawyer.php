<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Lawyer extends Model
{
    protected $guarded = [];
    protected $table = 'lawyers';
}
