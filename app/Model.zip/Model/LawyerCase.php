<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LawyerCase extends Model
{
    protected $guarded = [];
    protected $table = 'cases';

    public function documents()
    {
        return $this->hasMany(Document::class, 'case_id', 'id');
    }

    public function payments()
    {
        return $this->hasMany(Payment::class, 'case_id', 'id');
    }

    public function client()
    {
        return $this->belongsTo(Client::class, 'client_id', 'id');
    }

    public function type()
    {
        return $this->belongsTo(Type::class, 'type_id', 'id');
    }

    public function expensess()
    {
        return $this->hasMany(Expenses::class, 'case_id', 'id');
    }
}
