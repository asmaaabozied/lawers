<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Ssesiot extends Model
{
    protected $guarded = [];
    protected $table = 'ssesiots';


    public function cases()
    {
        return $this->belongsTo(LawyerCase::class, 'case_id', 'id');
    }


    public function lawer()
    {
        return $this->belongsTo(Lawyer::class, 'lawyer_id', 'id');
    }
}
