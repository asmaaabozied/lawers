<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Statuscase extends Model
{
    protected $guarded = [];
    protected $table = 'statuscases';
}
