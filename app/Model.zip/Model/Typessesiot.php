<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Typessesiot extends Model
{
    protected $guarded = [];
    protected $table = 'typessesiots';
}
