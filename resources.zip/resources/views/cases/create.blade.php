@extends('layouts.admin')
@section('title', 'اضافة قضية جديدة')
@section('content')

    <div class="col">
        <div class="widget-content widget-content-area br-6">
            <form action="{{route('case.store')}}" method="post">
                @csrf
                <x-input-text name="code" value="{{old('code')}}" title="الكؤد"></x-input-text>
                <x-input-text name="details" value="{{old('details')}}" title="صفه الموكل"></x-input-text>


                <x-input-text name="discount" value="{{old('discount')}}" title="الخصم"></x-input-text>

                <x-input-select name="client_id" value="id" title="العميل" oldValue="{{old('client_id')}}" hasEmptyOption="0" :collection="\App\Model\Client::all()" display="name"></x-input-select>

                <x-input-select name="type_id" value="id" title="النوع" oldValue="{{old('type_id')}}" hasEmptyOption="0" :collection="\App\Model\Type::all()" display="name"></x-input-select>

                <x-input-text name="number" value="{{old('number')}}" title="رقم القضية"></x-input-text>
                <x-input-text name="price" value="{{old('price')}}" title="الاتعاب"></x-input-text>
                <x-input-text name="auto_no" value="{{old('auto_no')}}" title="الرقم الالي للقضية"></x-input-text>
                <x-textarea name="notes" title="ملاحظات" value="{{old('notes')}}"></x-textarea>
                <x-textarea name="description" title="موضوع الدعوه" value="{{old('description')}}"></x-textarea>

                <button type="submit" class="btn btn-outline-primary">حفظ</button>
            </form>
        </div>
    </div>

@endsection
