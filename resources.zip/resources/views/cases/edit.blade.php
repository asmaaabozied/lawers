@extends('layouts.admin')
@section('title', 'اضافة قضية جديدة')
@section('content')

    <div class="col">
        <div class="widget-content widget-content-area br-6">
            <form action="{{route('case.update', $lawyerCase)}}" method="post">
                @csrf
                @method('PATCH')
                <x-input-text name="code" value="{{$lawyerCase['code']}}" title="الكؤد"></x-input-text>
                <x-input-text name="details" value="{{$lawyerCase['details']}}" title="صفه الموكل"></x-input-text>

                <x-input-text name="discount" value="{{$lawyerCase['discount']}}" title="الخصم"></x-input-text>

                <x-input-select name="client_id" value="id" title="العميل" oldValue="{{$lawyerCase['client_id']}}" hasEmptyOption="0" :collection="\App\Model\Client::all()" display="name"></x-input-select>

                <x-input-select name="type_id" value="id" title="النوع" oldValue="{{$lawyerCase['type_id']}}" hasEmptyOption="0" :collection="\App\Model\Type::all()" display="name"></x-input-select>


                <x-input-text name="number" value="{{$lawyerCase['number']}}" title="رقم القضية"></x-input-text>
                <x-input-text name="price" value="{{$lawyerCase['price']}}" title="الاتعاب"></x-input-text>
                <x-input-text name="auto_no" value="{{$lawyerCase['auto_no']}}" title="الرقم الالي للقضية"></x-input-text>
                <x-textarea name="notes" title="ملاحظات" value="{{$lawyerCase['notes']}}"></x-textarea>
                <x-textarea name="description" title="موضوع الدعوه" value="{{$lawyerCase['description']}}"></x-textarea>

                <button type="submit" class="btn btn-outline-primary">حفظ</button>
            </form>
        </div>
    </div>

@endsection
