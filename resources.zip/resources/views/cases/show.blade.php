@extends('layouts.admin')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area br-6">
            <div class="row">
                <div class="col">
                    <x-show-text title="رقم القضية" :value="$lawyerCase['number']"></x-show-text>
                    <x-show-text :value="$lawyerCase['details']" title="صفه الموكل"></x-show-text>

                    <x-show-text title="نوع القضية" :value="$lawyerCase->type->name"></x-show-text>
                    <x-show-text title="الاتعاب" :value="$lawyerCase['price']"></x-show-text>
                    <x-show-text title="اسم العميل" :value="$lawyerCase->client->name"></x-show-text>

                    <div class="form-group">
                        {{--                        <label class="font-weight-bold">الملاحظات</label>--}}
                        <x-textarea name="notes" :value="$lawyerCase['notes']" title="الملاحظات" width="100px">

                            <div class="border-width-2px">
                                {{$lawyerCase['notes']}}
                            </div>

                        </x-textarea>
                    </div>


                    <div class="form-group">
                        {{--                        <label class="font-weight-bold">الملاحظات</label>--}}
                        <x-textarea name="description" :value="$lawyerCase['description']" title="موضوع الدعوه"
                                    width="100px">

                            <div class="border-width-2px">
                                {{$lawyerCase['description']}}
                            </div>

                        </x-textarea>
                    </div>
                </div>
                <div class="col">
                    <x-show-text title="الخصم" :value="$lawyerCase->discount"></x-show-text>
                    <x-show-text title="الكود" :value="$lawyerCase->code"></x-show-text>


                    <x-show-text title="المدفوع" :value="$lawyerCase->payments->sum('value')"></x-show-text>
                    <x-show-text title=الباقي
                                 :value="$lawyerCase['price'] - $lawyerCase->payments->sum('value')"></x-show-text>

                </div>

            </div>
        </div>
    </div>

    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-content widget-content-area border-top-tab br-4">
            <ul class="nav nav-tabs mb-3 mt-3" id="borderTop" role="tablist">
                <li class="nav-item">
                    <a class="nav-link active" id="border-top-home-tab" data-toggle="tab" href="#border-top-home"
                       role="tab" aria-controls="border-top-home" aria-selected="true"><i data-feather="home"></i>المدفوعات</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" id="border-top-home-tabb" data-toggle="tab" href="#border-top-homee"
                       role="tab" aria-controls="border-top-home" aria-selected="true"><i data-feather="home"></i>المصروفات</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" id="border-top-profile-tab" data-toggle="tab" href="#border-top-profile"
                       role="tab" aria-controls="border-top-profile" aria-selected="false"><i data-feather="user"></i>المستندات</a>
                </li>
            </ul>
            <div class="tab-content" id="borderTopContent">
                <div class="tab-pane fade active show" id="border-top-home" role="tabpanel"
                     aria-labelledby="border-top-home-tab">
                    @include('cases.partials._payments')
                </div>


                <div class="tab-pane fade active show show" id="border-top-homee" role="tabpanel"
                     aria-labelledby="border-top-home-tabb">
                    @include('cases.partials.expense')
                </div>


                <div class="tab-pane fade" id="border-top-profile" role="tabpanel"
                     aria-labelledby="border-top-profile-tab">
                    @include('cases.partials._docs')
                </div>
            </div>

        </div>
    </div>
@endsection
