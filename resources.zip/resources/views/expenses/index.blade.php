@extends('layouts.admin')
@section('title', 'المصروفات')
@section('content')
    <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
        <div class="widget-header d-flex justify-content-between mb-3">
            <h3>الدفعات</h3>
            <a href="{{route('expense.create')}}" class="btn btn-outline-primary" title="اضافة جديد"><i data-feather="plus"></i></a>
        </div>
        <div class="widget-content widget-content-area br-6">
            <div class="table-responsive mb-4 mt-4">
                <table id="payments" class="table table-hover non-hover" style="width:100%">
                    <thead>
                    <tr>
                        <th>رقم المصروف</th>
                        <th>القيمة</th>
                        <th>التاريخ</th>
                        <th>التفاصيل</th>
                        <th>اجراء</th>
                    </tr>
                    </thead>
                    <tbody>

                    @foreach(\App\Model\Expense::all() as $item)
                        <tr>
                            <td>{{$item['id']}}</td>
                            <td>{{$item['value']}}</td>
                            <td>{{$item['date']}}</td>
                            <td>{{Str::limit($item['details'], 60)}}</td>
                            <td class="d-flex">
                                <a href="{{route('expense.show', $item)}}" class="text-primary mr-3"><i data-feather="eye"></i></a>
                                <a href="{{route('expense.edit', $item)}}" class="text-success mr-3"><i data-feather="edit"></i></a>
                                <form action="{{route('expense.destroy',$item)}}" method="post" onsubmit="return confirm('هل انت  متاكد ؟')">
                                    @csrf
                                    @method('DELETE')
                                    <button class="delete-btn text-danger p-0 m-0" type="submit"><i data-feather="trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
@push('javascript')
    <x-datatables id="payments" mass=""></x-datatables>
@endpush
